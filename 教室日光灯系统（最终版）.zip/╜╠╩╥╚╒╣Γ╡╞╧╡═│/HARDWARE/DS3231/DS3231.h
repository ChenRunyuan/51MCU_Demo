#ifndef __DS3231_H__
#define __DS3231_H__
#include "sys.h"

typedef struct 
{
	u8	hour;
	u8	min;
	u8	sec;			
	u32 year;
	u8  month;
	u8  date;
	u8  week;		
	u8	temper_H;
	u8	temper_L;
	u8  Run_sec;
	u8  Run_min;
	u8  Run_hour;

	
}Calendar_OBJ;

static 	u8  Set_min;
extern Calendar_OBJ Time;	//�����ṹ��

extern u8 const mon_table[12];	//�·��������ݱ�

u16 B_BCD(u8 val);
void DS3231_WR_Byte(u8 addr,u8 bytedata);
void DS3231_Init(void);
void Get_DS3231_Time(void);      
//u8 RTC_Get_Week(u16 year,u8 month,u8 day);
void Set_DS3231_Time(u8 syear,u8 smon,u8 sday,u8 hour,u8 min,u8 sec,u8 week);//����ʱ��	

#endif
