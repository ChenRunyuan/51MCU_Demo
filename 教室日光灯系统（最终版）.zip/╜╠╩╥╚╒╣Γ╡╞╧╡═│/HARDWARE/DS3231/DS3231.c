#include "DS3231.h"
#include "i2c_soft.h"
#include "delay.h"

#define DS3231_WriteAddress		0xD0   
#define DS3231_ReadAddress		0xD1
//bcdתhex
u8 BCD2HEX(u8 val)
{
    u8 i;
    i= val&0x0f;
    val >>= 4;
    val &= 0x0f;
    val *= 10;
    i += val;
    
    return i;
}


u16 B_BCD(u8 val)
{
	u8 i,j,k;
	i=val/10;
	j=val%10;
	k=j+(i<<4);
	return k;
}


void DS3231_WR_Byte(u8 addr,u8 bytedata)
{
	I2C_Start();
	I2C_SendByte(DS3231_WriteAddress);
	I2C_WaitAck();
	I2C_SendByte(addr);
	I2C_WaitAck();
	I2C_SendByte(bytedata);
	I2C_WaitAck();
	I2C_Stop();
}	


u8 DS3231_RD_Byte(u8 addr)
{
	u8 Dat=0;
  
	I2C_Start();
	I2C_SendByte(DS3231_WriteAddress);
	I2C_WaitAck();
	I2C_SendByte(addr);
	I2C_WaitAck();
	I2C_Start();
	I2C_SendByte(DS3231_ReadAddress);
	I2C_WaitAck();
	Dat=I2C_ReceiveByte();
	I2C_Stop();
	
	return Dat;
} 

//ds3231��ʼ������
void DS3231_Init(void)
{
	I2C_GPIO_Config();
	DS3231_WR_Byte(0x0e,0);
	delay_ms(2); 
  DS3231_WR_Byte(0x0f,0x0);
	delay_ms(2); 
}

//u8 rtc_address[8]={0x00,0x01,0x02,0x04,0x05,0x03,0x06,0x11};//���ʱ�������� ���λ��дλ
//void DS3231_write_time()//д��ʱ��
//{
//    u8 i,tmp;
//    for(i=0;i<7;i++)
//    {      
//        tmp=RTC_Data[i]/10;//BCD����
//        RTC_Data1[i]=RTC_Data[i]%10;
//        RTC_Data1[i]=RTC_Data1[i]+tmp*16;
//    }
//    for(i=0;i<7;i++)
//    {
//        DS3231_WR_Byte(rtc_address[i],RTC_Data1[i]);
//    }
//    DS3231_WR_Byte(0x0e,0x0c);
//}

//DS3231��ʼ�����ú����� �� �� �� ʱ �� �� �ܣ�
void Set_DS3231_Time(u8 yea,u8 mon,u8 da,u8 hou,u8 min,u8 sec,u8 week)
{
	u8 temp=0;
  
	temp=B_BCD(yea);
	DS3231_WR_Byte(0x06,temp);  
	temp=B_BCD(mon);
	DS3231_WR_Byte(0x05,temp); 
	temp=B_BCD(da);
	DS3231_WR_Byte(0x04,temp); 
	temp=B_BCD(hou);
	DS3231_WR_Byte(0x02,temp); 
	temp=B_BCD(min);
	DS3231_WR_Byte(0x01,temp);  
	temp=B_BCD(sec);
	DS3231_WR_Byte(0x00,temp);
	temp=B_BCD(week);
	DS3231_WR_Byte(0x03,temp);
}


void Get_DS3231_Time(void)
{
	Time.year=DS3231_RD_Byte(0x06);  
	Time.year=BCD2HEX(Time.year);

	Time.month=DS3231_RD_Byte(0x05); 
  Time.month=BCD2HEX(Time.month);;

	Time.date=DS3231_RD_Byte(0x04);  
	Time.date=BCD2HEX(Time.date);
	 
	Time.hour=DS3231_RD_Byte(0x02); 
	Time.hour&=0x3f;                   
	Time.hour=BCD2HEX(Time.hour);

	Time.min=DS3231_RD_Byte(0x01);
	Time.min=BCD2HEX(Time.min);

	Time.sec=DS3231_RD_Byte(0x00);
	Time.sec=BCD2HEX(Time.sec);
	
	Time.week=DS3231_RD_Byte(0x03);
	Time.week=BCD2HEX(Time.week);
	
	DS3231_WR_Byte(0x0e,0x20);
	Time.temper_H=DS3231_RD_Byte(0x11);
	Time.temper_L=(DS3231_RD_Byte(0x12)>>6)*25;
}

