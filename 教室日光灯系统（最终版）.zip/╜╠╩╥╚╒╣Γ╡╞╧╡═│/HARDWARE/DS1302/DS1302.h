#ifndef _DS1302_H
#define _DS1302_H


#include "sys.h"

#define DS1302_IO_IN()  {GPIOA->CRL&=0XFF0FFFFF;GPIOA->CRL|=8<<20;}
#define DS1302_IO_OUT() {GPIOA->CRL&=0XFF0FFFFF;GPIOA->CRL|=3<<20;}

struct sTime {  //日期时间结构
    uint16_t year; //年
    uint8_t mon;   //月
    uint8_t day;   //日
    uint8_t hour;  //时
    uint8_t min;   //分
    uint8_t sec;   //秒
    uint8_t week;  //星期
};

#define	  TSCLK  PAout(4) //数据端口	
#define	  TIO   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)
#define	  TRST  PAout(6)  //数据端口



void Init_DS1302(void); //初始化DS1302，并设置默认时间
void GetRealTime(struct sTime *time);  //获取DS1302时钟日历数据
void SetRealTime(struct sTime *time);  //设置DS1302时钟日历数据

#endif

