#ifndef __LED_H
#define __LED_H	 

#include "sys.h" 

#define LED1 PBout(10)
#define LED2 PBout(11)

#define ON  0
#define OFF 1

void LED_Init(void);//��ʼ��

		 				    
#endif
