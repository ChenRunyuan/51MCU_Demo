#ifndef __I2C_H  
#define __I2C_H  
  
#include "reg51.h"  

sbit SCL_PIN  = P1^0;     
sbit SDA_PIN  = P1^1;      
      
#define SCL_H     SCL_PIN=1
#define SCL_L     SCL_PIN=0 
         
#define SDA_H     SDA_PIN=1    
#define SDA_L     SDA_PIN=0    
     
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Ack(void);
void I2C_NoAck(void);
unsigned char  I2C_WaitAck(void);
void I2C_SendByte(unsigned char SendByte);
unsigned char   I2C_ReceiveByte(void);
      
#endif 
