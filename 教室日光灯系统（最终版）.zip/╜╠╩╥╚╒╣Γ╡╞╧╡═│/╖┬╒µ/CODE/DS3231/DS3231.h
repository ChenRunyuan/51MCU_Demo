#ifndef __DS3231_H__
#define __DS3231_H__

typedef struct 
{
	unsigned char 	hour;
	unsigned char 	min;
	unsigned char 	sec;			
	unsigned int    year;
	unsigned char   month;
	unsigned char   date;
	unsigned char   week;		
	unsigned char 	temper_H;
	unsigned char 	temper_L;
	
}Calendar_OBJ;

extern Calendar_OBJ Time;	//�����ṹ��

extern unsigned char  const mon_table[12];	//�·��������ݱ�

unsigned int  B_BCD(unsigned char  val);
void DS3231_WR_Byte(unsigned char  addr,unsigned char  bytedata);
void DS3231_Init(void);
void Get_DS3231_Time(void);      
//unsigned char  RTC_Get_Week(u16 year,unsigned char  month,unsigned char  day);
void Set_DS3231_Time(unsigned char  syear,unsigned char  smon,unsigned char  sday,unsigned char  hour,unsigned char  min,unsigned char  sec,unsigned char  week);//����ʱ��	

#endif
