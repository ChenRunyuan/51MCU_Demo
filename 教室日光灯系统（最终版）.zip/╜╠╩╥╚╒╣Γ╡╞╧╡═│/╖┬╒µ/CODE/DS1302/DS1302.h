#ifndef _DS1302_H_
#define _DS1302_H_

#include "reg51.h"

#define uchar unsigned char
#define uint unsigned int
		
#define DS1302_W_ADDR 0xBE
#define DS1302_R_ADDR 0xBF

sbit SDA=P2^5;
sbit SCK=P2^6;
sbit RST=P2^7;

// ʱ�䣺���ʱ��������
typedef struct time
{
	uchar sec;
	uchar min;
	uchar hour;
	uchar day;
	uchar mon;
	uchar week;
	uchar year;
	uchar Run_sec;
	uchar Run_min;
}Calendar_OBJ;

// ���ӣ���ʱ
typedef struct alarm
{
	uchar min;
	uchar hour;
}ALARM;



void set_time(uchar *timedata);
void read_time(uchar *timedata);


#endif 
